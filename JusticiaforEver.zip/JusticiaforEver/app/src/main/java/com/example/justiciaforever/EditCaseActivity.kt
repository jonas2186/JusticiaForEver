package com.example.justiciaforever

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class EditCaseActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_case)

        val etEditCaseCode: EditText = findViewById(R.id.etEditCaseCode)
        val etEditDate: EditText = findViewById(R.id.etEditDate)
        val etEditClientName: EditText = findViewById(R.id.etEditClientName)
        val etEditAddress: EditText = findViewById(R.id.etEditAddress)
        val etEditPhoneNumber: EditText = findViewById(R.id.etEditPhoneNumber)
        val etEditEmail: EditText = findViewById(R.id.etEditEmail)
        val etEditArea: EditText = findViewById(R.id.etEditArea)
        val etEditDescription: EditText = findViewById(R.id.etEditDescription)
        val btnEditAttachDocs: Button = findViewById(R.id.btnEditAttachDocs)
        val btnSaveCase: Button = findViewById(R.id.btnSaveCase)

        btnSaveCase.setOnClickListener {
            // Lógica para guardar los cambios del caso
        }

        btnEditAttachDocs.setOnClickListener {
            // Lógica para adjuntar documentos
        }
    }
}

