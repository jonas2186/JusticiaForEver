package com.justiciaforever

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        btnLogin.setOnClickListener {
            val userCode = etUserCode.text.toString()
            val password = etPassword.text.toString()

            // Validar credenciales (esto es solo un ejemplo, deberías conectar con tu backend)
            if (userCode == "admin" && password == "admin") {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            } else {
                // Mostrar mensaje de error
            }
        }
    }
}



