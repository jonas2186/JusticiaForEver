package com.justiciaforever

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvWelcome.text = "Bienvenido, [Nombre]" // Cambiar por el nombre real del abogado

        btnCreateCase.setOnClickListener {
            val intent = Intent(this, CreateCaseActivity::class.java)
            startActivity(intent)
        }

        btnViewArchivedCases.setOnClickListener {
            // Implementar la lógica para ver casos archivados
        }

        btnViewCourts.setOnClickListener {
            // Implementar la lógica para ver sedes
        }
    }
}


