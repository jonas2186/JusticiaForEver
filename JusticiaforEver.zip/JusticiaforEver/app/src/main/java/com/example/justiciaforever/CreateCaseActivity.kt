package com.justiciaforever

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_create_case.*

class CreateCaseActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_case)

        btnAddCase.setOnClickListener {
            val caseCode = etCaseCode.text.toString()
            val date = etDate.text.toString()
            val clientName = etClientName.text.toString()
            val address = etAddress.text.toString()
            val phone = etPhone.text.toString()
            val email = etEmail.text.toString()
            val caseArea = etCaseArea.text.toString()
            val caseDescription = etCaseDescription.text.toString()

            // Aquí debes agregar la lógica para guardar el caso en la base de datos o backend
        }
    }
}


