package com.example.justiciaforever

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val etSearch: EditText = findViewById(R.id.etSearch)
        val btnCreateCase: Button = findViewById(R.id.btnCreateCase)
        val btnViewCases: Button = findViewById(R.id.btnViewCases)
        val btnViewArchived: Button = findViewById(R.id.btnViewArchived)
        val btnViewOffices: Button = findViewById(R.id.btnViewOffices)

        btnCreateCase.setOnClickListener {
            val intent = Intent(this, CreateCaseActivity::class.java)
            startActivity(intent)
        }

        btnViewCases.setOnClickListener {
            val intent = Intent(this, ViewCasesActivity::class.java)
            startActivity(intent)
        }

        btnViewArchived.setOnClickListener {
            val intent = Intent(this, ViewArchivedActivity::class.java)
            startActivity(intent)
        }

        btnViewOffices.setOnClickListener {
            val intent = Intent(this, ViewOfficesActivity::class.java)
            startActivity(intent)
        }
    }
}
